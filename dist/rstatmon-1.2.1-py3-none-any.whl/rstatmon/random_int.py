import random

i = random.random()
print(i)
#"print(50)
